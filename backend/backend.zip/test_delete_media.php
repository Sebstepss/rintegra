<?php

require_once __DIR__ . '/vendor/autoload.php';

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;
use App\Models\Media;

// Crear la aplicación Laravel
$app = new Application(realpath(__DIR__));
$app->singleton(
    Illuminate\Contracts\Http\Kernel::class,
    App\Http\Kernel::class
);
$app->singleton(
    Illuminate\Contracts\Console\Kernel::class,
    App\Console\Kernel::class
);
$app->singleton(
    Illuminate\Contracts\Debug\ExceptionHandler::class,
    App\Exceptions\Handler::class
);

$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$kernel->bootstrap();

echo "Testing Media deletion...\n\n";

// Buscar el media más reciente
$media = Media::latest()->first();

if (!$media) {
    echo "No media found in database.\n";
    exit;
}

echo "Found media:\n";
echo "ID: {$media->id}\n";
echo "Name: {$media->name}\n";
echo "Path: {$media->path}\n";
echo "File name: {$media->file_name}\n";

// Verificar si el archivo existe
$fullPath = storage_path('app/public/' . $media->path);
echo "Full path: {$fullPath}\n";
echo "File exists: " . (file_exists($fullPath) ? "YES" : "NO") . "\n";

// Probar método fileExists del modelo
echo "Media->fileExists(): " . ($media->fileExists() ? "YES" : "NO") . "\n";

// Intentar eliminar usando el método del modelo
echo "\nAttempting to delete file...\n";
$result = $media->deleteFile();
echo "deleteFile() result: " . ($result ? "SUCCESS" : "FAILED") . "\n";

// Verificar de nuevo si el archivo existe
echo "File exists after delete: " . (file_exists($fullPath) ? "YES" : "NO") . "\n";

echo "\nNOTE: Database record was NOT deleted in this test.\n";