<?php

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Media;
use App\Http\Controllers\MediaController;
use Illuminate\Http\Request;

echo "Testing MediaController delete method...\n";

// Obtener el media más reciente  
$media = Media::latest()->first();

if (!$media) {
    echo "No media found.\n";
    exit;
}

echo "Media before delete:\n";
echo "ID: {$media->id}\n";
echo "Name: {$media->name}\n";  
echo "Path: {$media->path}\n";
echo "File exists: " . ($media->fileExists() ? "YES" : "NO") . "\n";

// Simular eliminación usando el controlador
$controller = new MediaController();

try {
    echo "\nCalling controller destroy method...\n";
    $response = $controller->destroy($media);
    echo "Controller response: " . $response->getContent() . "\n";
    
    // Verificar si el registro fue eliminado de la base de datos
    $stillExists = Media::find($media->id);
    echo "Record exists in DB after delete: " . ($stillExists ? "YES" : "NO") . "\n";
    
    // Verificar si el archivo físico fue eliminado
    $fullPath = storage_path('app/public/' . $media->path);
    echo "Physical file exists after delete: " . (file_exists($fullPath) ? "YES" : "NO") . "\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}