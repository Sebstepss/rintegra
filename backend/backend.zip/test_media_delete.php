<?php

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Media;

echo "Testing media deletion...\n";

// Get the latest media
$media = Media::latest()->first();

if (!$media) {
    echo "No media found.\n";
    exit;
}

echo "Media ID: {$media->id}\n";
echo "Name: {$media->name}\n";  
echo "Path: {$media->path}\n";

// Check if file exists using the model method
echo "fileExists(): " . ($media->fileExists() ? "YES" : "NO") . "\n";

// Check physical file path
$fullPath = storage_path('app/public/' . $media->path);
echo "Full path: {$fullPath}\n";
echo "Physical file exists: " . (file_exists($fullPath) ? "YES" : "NO") . "\n";

// Try to delete the file
echo "\nDeleting file...\n";
$deleteResult = $media->deleteFile();
echo "Delete result: " . ($deleteResult ? "SUCCESS" : "FAILED") . "\n";

// Check again
echo "fileExists() after delete: " . ($media->fileExists() ? "YES" : "NO") . "\n";
echo "Physical file exists after delete: " . (file_exists($fullPath) ? "YES" : "NO") . "\n";