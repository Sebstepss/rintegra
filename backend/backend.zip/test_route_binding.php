<?php

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Media;
use App\Http\Controllers\MediaController;
use Illuminate\Http\Request;

echo "Testing route model binding for media deletion...\n";

// Create a new media record for testing
$testMedia = Media::create([
    'name' => 'test-image.jpg',
    'file_name' => 'test-123.jpg',
    'mime_type' => 'image/jpeg',
    'extension' => 'jpg',
    'size' => 1000,
    'path' => 'test/test-123.jpg',
    'url' => '/storage/test/test-123.jpg',
    'type' => 'image',
    'uploaded_by' => null
]);

echo "Created test media with ID: {$testMedia->id}\n";

// Test route model binding
echo "\n--- Testing route model binding ---\n";
$foundMedia = Media::find($testMedia->id);
echo "Can find media by ID {$testMedia->id}: " . ($foundMedia ? "YES" : "NO") . "\n";

// Test controller destroy with the bound model
echo "\n--- Testing controller destroy ---\n";
$controller = new MediaController();

try {
    $response = $controller->destroy($foundMedia);
    echo "Controller destroy response: " . $response->getContent() . "\n";
    
    // Check if deleted
    $stillExists = Media::find($testMedia->id);
    echo "Media still exists after controller destroy: " . ($stillExists ? "YES" : "NO") . "\n";
    
} catch (Exception $e) {
    echo "Error in controller destroy: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}