<?php

namespace App\Http\Controllers;

use App\Models\Content;
use Illuminate\Http\Request;

class ContentController extends Controller
{
    public function index()
    {
        return Content::with('page')->get();
    }

    public function store(Request $request)
    {
        $request->validate([
            'page_id' => 'required|exists:pages,id',
            'content_type' => 'required|string',
            'content_data' => 'required|array',
            'order' => 'integer'
        ]);

        $content = Content::create($request->all());
        return response()->json($content, 201);
    }

    public function show(Content $content)
    {
        return $content->load('page');
    }

    public function update(Request $request, Content $content)
    {
        $request->validate([
            'page_id' => 'required|exists:pages,id',
            'content_type' => 'required|string',
            'content_data' => 'required|array',
            'order' => 'integer'
        ]);

        $content->update($request->all());
        return $content;
    }

    public function destroy(Content $content)
    {
        $content->delete();
        return response()->json(null, 204);
    }

    public function updateOrder(Request $request)
    {
        $request->validate([
            'contents' => 'required|array',
            'contents.*.id' => 'required|exists:contents,id',
            'contents.*.order' => 'required|integer'
        ]);

        foreach ($request->contents as $contentData) {
            Content::where('id', $contentData['id'])->update(['order' => $contentData['order']]);
        }

        return response()->json(['message' => 'Order updated successfully']);
    }
}