<?php

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Media;
use App\Http\Controllers\MediaController;

echo "Testing MediaController destroy method with more debugging...\n";

// Find existing media
$media = Media::find(6);

if (!$media) {
    echo "Media with ID 6 not found.\n";
    exit;
}

echo "Found media:\n";
echo "ID: {$media->id}\n";
echo "Name: {$media->name}\n";

// Test controller destroy method step by step
$controller = new MediaController();

echo "\n--- Testing deleteFile() method directly ---\n";
$deleteFileResult = $media->deleteFile();
echo "deleteFile() result: " . ($deleteFileResult ? "SUCCESS" : "FAILED") . "\n";

echo "\n--- Testing model delete() method directly ---\n";
try {
    $deleted = $media->delete();
    echo "Model delete() result: " . ($deleted ? "SUCCESS" : "FAILED") . "\n";
    
    // Check if still exists in database
    $stillExists = Media::find(6);
    echo "Still exists in DB: " . ($stillExists ? "YES" : "NO") . "\n";
    
} catch (Exception $e) {
    echo "Error during delete: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}